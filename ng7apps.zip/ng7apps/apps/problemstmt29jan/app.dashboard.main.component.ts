import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-dashboardmain-component",
    template: `

            <a [routerLink]="['dashboard']">Dashboard</a> &nbsp; &nbsp;

            <a [routerLink]="['login']">Login</a> &nbsp; &nbsp;
        
            <a [routerLink]="['registration']">Registration</a>
        
    <hr/>
   <router-outlet></router-outlet>    
    `
})
export class DashboardMainComponent implements OnInit{
   
    constructor(){
       
    }
    ngOnInit():void{}
}