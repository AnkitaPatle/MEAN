import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';
import {Product,Products} from './product.model'; 

@Component({
    selector: 'product-data',
    template: `
    <h3>Product in Category : {{categoryName}}</h3>
<table class="table table-striped table-bordered">
     <thead>
        <tr>
            <td>Product Id</td>
            <td>Product Name</td>
            <td>Product Price</td>
            <td>Cateogry</td>
        </tr>
     </thead>
     <tbody>
         <tr *ngFor="let prd of filterProducts">
             <td>{{prd.productId}}</td>
             <td>{{prd.productName}}</td>
             <td>{{prd.productPrice}}</td>
             <td>{{prd.categoryName}}</td>
         </tr>
     </tbody>
</table>
    `
})
export class ProductComponentC implements OnInit {
    products = Products
    _filterProduct:Array< Product >;
    _categoryName:string;
   
    counter: number = 0;

    @Output()
    changedEmitter:EventEmitter<number>;

  @Input()
  set categoryName(cname: string) {
    this._categoryName = (cname && cname.trim()) || 'No Category Selected';
  }
  get categoryName() { 
      return this._categoryName; 
  }    
 
    constructor() { 
         this._filterProduct = new Array< Product >();
         console.log('Product');
         this.changedEmitter = new EventEmitter<number>();
    } 
 
  get filterProducts() { 
           this._filterProduct = new Array<Product>();
          for(let e of Products){
            if(e.categoryName==this._categoryName){
                this._filterProduct.push(e);
                this.valueChange();
            }
        } 
      return this._filterProduct; 
    }

    valueChange():void{
       // console.log("counter :"+this.counter)
        this.counter = this._filterProduct.length > 0 ? this._filterProduct.length : 0;
        this.changedEmitter.emit(this.counter);
        console.log("Counter::"+this.counter)
    }
    ngOnInit() { }
}