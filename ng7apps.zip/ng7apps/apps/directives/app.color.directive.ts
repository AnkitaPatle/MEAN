import { Directive } from "@angular/core";

@Directive({
    selector: "[setColor]"
})

export class ColorDirective {
    constructor() {
        
    }
}