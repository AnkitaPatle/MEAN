var q = require(`q`);
var http = require(`http`);

module.exports = {
    getdata: function(option){
        var prod = ``;
        var defer = q.defer();
        var request;
        if(!option){
            defer.reject(`Please specify the url to receive data`);
        }else{
            request =http.request(option, function(response){
                response.setEncoding(`utf-8`);
                response.on(`data`,function(chunk){
                    prod +=chunk;
                });
                response.on(`end`, function(){
                    try{
                        var receivedJSON = JSON.parse(prod);
                        defer.resolve(receivedJSON);
                    }catch (error){
                        defer.reject(error);
                    }
                });
            });
        }
        request.end();
        return defer.promise;
    }
};