var callModule = require(`./moduleapp2`);

var serverDetails = {

    host: "apiapptrainingservice.azurewebsites.net",
    path: "/api/Products",
    method: "GET"
};
var prod = [];
callModule.getdata(serverDetails).then(function(response){
    console.log(`BasePrice "\t" CategoryName "\t" Description "\t" Manufacturer "\t" ProductId "\t" ProductName "\t" ProductRowId`);
    console.log();
    for(var i=0; i<response.length; i++){
        console.log(response[i].BasePrice + `\t` +response[i].CategoryName + `\t` + response[i].Description + `\t` +response[i].Manufacturer + `\t` + response[i].ProductId + `\t` +response[i].ProductName + `\t`+ response[i].ProductRowId);        
    }    
}).catch(function(err){
    console.log(err);    
});
console.log(`DONE`);
