// 1. Create a file and add data in it

// 2. Load the fs module
var fs= require("fs");

// 3. Write file with sync call

fs.writeFileSync("./myfile.txt","I am a text file");
console.log("File is written");

// 4. Read filke with sync file
var data = fs.readFileSync("./myfile.txt");
console.log(data.toString());

