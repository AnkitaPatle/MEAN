var fs=require("fs");

fs.mkdir("./newFolder",function(err){
    if(err){
        console.log(err.message);
        return;
    }
    console.log("Folder created");    
    fs.writeFile("./newFolder/myasyncfilenew.txt","Data entered in new folder...", function(err){
        if(err){
            console.log(err.message);
            return;            
        } 
        console.log("File created");
        fs.readFile("./newFolder/myasyncfilenew.txt", function(err,data){
            if(err){
            console.log(err.message);
            return;
            }
            console.log(data.toString());
        });       
   });   
});
console.log("Done");
