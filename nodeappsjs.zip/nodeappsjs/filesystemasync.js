var fs=require("fs");

// 1. write file using async call
fs.writeFile("./myasyncfile.txt", "This is async file",function(err){
    if(err){
        console.log(err.message);
        return;
        
    }
    console.log("File written successfully......");
    fs.readFile("./myasyncfile.txt", function(err,data){
        if(err){
            console.log(err.message);
            return;            
        }
        console.log(data.toString());
        
    });
});

fs.appendFile("./myasyncfile.txt", " ..this data is appended......",function(err){
    if(err){
        console.log(err.message);
        return;
    }
       
});
console.log("DONE");
