
var mongoose = require("mongoose");
mongoose.Promise = global.Promise;

// 1. Model-Schema-Mapping with collection on Mongo DB and establishing collection with it.
mongoose.connect("mongodb://localhost/ProductsAppDb", {useNewUrlParser: true});
// 1a. get the connection object
// if dbconnect is not undefined then the connection is successfull
var dbConnect = mongoose.connection;
if(!dbConnect){
    console.log("sorry connection not established");
    return;
}
// 1b. define schema (recommended to have same attributes as per the collection)
var userSchema = mongoose.Schema({
    UserId: String,
    Password: String,
});
// 1c. map the schema with collection
                                        //    name     Schema     collection
module.exports = userModel = mongoose.model("usermode", userSchema, "usermodel");