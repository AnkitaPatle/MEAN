// custome node module file

var Products = [
    {id:101, name:"p1"},
     {id:102, name: "p2"}
    ];

module.exports = {
    getdata: function(){
        return Products;
    },

    addData: function(prd){
        Products.push(prd);
        return Products;
    },

    putData: function(prd,id){
       /*  var err = {
            'messege':'element not found'
        }; */
        // var errr;
        Products.forEach(element => {
            if(element.id ==id){
                element.id = id,
                element.name = prd.name
            }
            // else{
            //     errr = true;
            // }
        });
    //     if(!errr){
         return Products;
    // }
    // else{
    //     return err;
    // }
},
deleteData: function(prd, id){
        Products.forEach(element => {
            if(element.id == id){
                element.id = prd.id,
                element.name = prd.name              
            }
});
    return Products;
}
}