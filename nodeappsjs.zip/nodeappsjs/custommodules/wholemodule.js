/* module.exports = {

    add: function(x,y){
        return parseInt(x) + parseInt(y);
    },

    mult: function(x,y){
        return parseInt(x) * parseInt(y);
    }
}; */

module.exports = {

    getfile:function(filename){
        //var urls:"",
    }
};