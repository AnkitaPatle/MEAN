exports.caseutitily = function(str,choice){
    if(choice==="U"){
        return str.toUpperCase();
    }
    if(choice==="L"){
        return str.toLowerCase();
    }
};

exports.reverse = function(str){
    var rec = "";
    for(var i =str.length;i>0;i++){
        rec += str[i];
    }
    return str;
};