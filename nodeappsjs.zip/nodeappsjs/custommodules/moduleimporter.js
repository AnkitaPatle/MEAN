var util = require("./utilitymodule");
var math = require("./wholemodule");


var str = "Node.js";

console.log(`case with upper for ${str} is ${util.caseutitily(str,"U")}`);
console.log(`case with Lower for ${str} is ${util.caseutitily(str,"L")}`);

console.log(`Reverse of  ${str} = ${util.reverse(str)}`);

console.log(`Addition: ${math.add(3,4)}`);
console.log(`Addition: ${math.mult(3,4)}`);

