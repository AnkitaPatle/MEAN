import { Component, OnInit } from "@angular/core";
import { Users } from "./app.login.model";
import { AppGuardService } from "../services/app.test.guard.service";

@Component({
    selector: "app-login-component",
    template:`
    
    <div class="container">
    <h3 class="page-header">Login</h3><br/>
    
    <div class="form-group">
    Username
    <input type="text" class="form-control" name="userid" [(ngModel)]="UserId" placeholder="Enter UserId"/>
    </div>

    <div class="form-group">
    Password
    <input type="password" class="form-control" name="password" [(ngModel)]="Password" placeholder="Enter Password"/>
    </div>
    
    <input type="reset" class="btn btn-primary" value="Cancel"/> &nbsp;
    <input type="submit" class="btn btn-primary" value="Login"/>
    </div>
    `

})
export class LoginComponent implements OnInit{
    UserId:String;
    Password: String;
    
    ngOnInit():void{
       console.log(this.UserId);
       
    }
}
