import { Component, OnInit } from "@angular/core";
import { SampleService } from "./../../services/app.sample.service";

@Component({
    selector: "app-sampleservice-component",
    template:`
    <input type="button" value="Get data" (click)="getdata()" />`
 
})

export class SampleServiceComponent implements OnInit{
    constructor(private serv:SampleService){    }
    ngOnInit():void{}
    getdata():void{
        let data = this.serv.getProducts();
        console.log(JSON.stringify(data));
        
    }
}