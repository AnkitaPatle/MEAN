export class Product{
    constructor(
        public _id:string,
        public ProductID:number,
        public ProductName:string,
        public CategoryName:string,
        public Manufacturer:string,
        public Price:number
    ){}
}