// 1. explicit data-type
var num1 = 200;
// 2. implicit data-type, based on type-of initial value
var num2 = 200;
function performOperation(val) {
    if (typeof (val) === "number") {
        console.log("Square" + (val * val));
    }
    else {
        if (typeof (val) === "string") {
            console.log("Upper Case " + val.toUpperCase());
        }
        else {
            console.log("Sorry!! Type not found to process " + val);
        }
    }
}
performOperation(10);
performOperation("Ankita");
performOperation(true);
function unionTypeOperation(val) {
    if (typeof (val) === "number") {
        console.log("Square" + (val * val));
    }
    if (typeof (val) === "string") {
        console.log("Upper Case " + val.toUpperCase());
    }
}
unionTypeOperation(10);
unionTypeOperation("Ram");
