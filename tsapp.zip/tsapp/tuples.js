// 1. simple tuple
// tuple contains first value as string and 2nd as number
var val;
//rules for tuples
// 1. value type must be followed by tuple
// 2. tuple must be initialized
val = ["A", 101]; //initialization
console.log(val[0] + " " + val[1]);
var productRecord; //Defining a reference type of TupleData
// Initializing TupleData reference type
productRecord = [1, { ProductID: 101, ProductName: "Laptop" }];
productRecord.push([2, { ProductID: 102, ProductName: "Desktop" }]);
productRecord.push([3, { ProductID: 103, ProductName: "Router" }]);
for (var _i = 0, productRecord_1 = productRecord; _i < productRecord_1.length; _i++) {
    var p = productRecord_1[_i];
    console.log(p);
}
