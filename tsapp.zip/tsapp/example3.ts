type product = [number,{}];

let productRec: product;

productRec = [1, {ProductID:101,ProductName:"Laptop", CategoryName:"Hardware", MenufacturerName:"Dell", ProductPrice:"50000"}];
productRec.push([2, {ProductID:102,ProductName:"Desktop",  CategoryName:"Hardware", MenufacturerName:"HP", ProductPrice:"20000"}]);
productRec.push([3, {ProductID:103,ProductName:"Router", CategoryName:"Hardware", MenufacturerName:"Dell", ProductPrice:"60000"}]);
