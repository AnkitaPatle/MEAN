//The JSON object aka object literal
var product = {
    ProductID: 101,
    ProductName: "Laptop"
};
// 1. JSON serialization aka string parsing for JSON
console.log(JSON.stringify(product));
// 2. gettng length of all keys of JSON object
var info = Object.keys(product).length;
console.log(info);
console.log();
// 3. Read all property names
for (var _i = 0, _a = Object.keys(product); _i < _a.length; _i++) {
    var p = _a[_i];
    console.log(p);
}
var namesData = [];
namesData.push({ id: 102, name: "A" });
namesData.push({ id: 102, name: "B" });
namesData.push({ id: 102, name: "C" });
namesData.push({ id: 102, name: "D" });
