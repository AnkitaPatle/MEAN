var MathClass = /** @class */ (function () {
    function MathClass(x, y) {
        this.x = x;
        this.y = y;
        //  private x:number = 0;
        //  private y:number = 0;
        this.z = 0;
        //this.x = x;
        //this.y = y;
    }
    MathClass.prototype.add = function () {
        this.z = this.x + this.y;
        return this.z;
    };
    MathClass.prototype.sub = function () {
        this.z = this.x - this.y;
        return this.z;
    };
    return MathClass;
}());
var mObj = new MathClass(20, 40);
console.log("add = " + mObj.add());
console.log("add = " + mObj.add());
