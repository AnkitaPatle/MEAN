var names = []; //Declaration with default initialization
names.push("A");
names.push("B");
names.push("C");
names.push("D");
//Traditional Iteration using for loop
console.log("Using for loop");
for (var i = 0; i < names.length; i++) {
    console.log("names at ${i} is ${names[i]}");
}
console.log();
//ES 5 Iteration using for..in loop
//simplication of for loop
for (var i in names) {
    console.log("names at ${i} is ${names[i]}");
}
console.log();
//Iterator using for..of loop
//internally uses symbole.iterator() of ES6
//Typescript uses for loop for symbole.iterator
console.log("Using for..of loop");
for (var _i = 0, names_1 = names; _i < names_1.length; _i++) {
    var n = names_1[_i];
    console.log('Name = ${n}');
}
console.log();
