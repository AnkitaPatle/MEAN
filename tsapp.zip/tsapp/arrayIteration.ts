let names: [] = [];  //Declaration with default initialization

names.push("Agdsdh");
names.push("Bnxcn jhbcjhd");
names.push("Cjcjc");
names.push("Dhch");

//Traditional Iteration using for loop
console.log("Using for loop");
for(let i=0;i<names.length;i++){
    console.log(`names at ${i} is ${names[i]}`);
}
console.log();

//ES 5 Iteration using for..in loop
//simplication of for loop
for(let i in names){
    console.log(`names at ${i} is ${names[i]}`);
}
console.log();

//Iterator using for..of loop
//internally uses symbole.iterator() of ES6
//Typescript uses for loop for symbole.iterator
console.log("Using for..of loop");
for(let n of names){
    console.log(`Name = ${n}`);
}
console.log();