let arr1: Array<string>;
arr1 = new Array<string>();
let arr2 =[];

arr1.push("ankita");
arr1.push("Shobha");
arr1.push("mahesh");
arr1.push("Rahul");
arr1.push("ram");
arr1.push("neha");

for(var i:any=0;i<arr1.length;i++){
    for(var j:any=0;j<arr1.length;j++){

        let char1 = arr1[i].charAt(0);
        let char2 = arr1[j].charAt(0);

        if(char1.toUpperCase() === char2){
            arr2.push(arr1[i]);

        }
    }
}
console.log(arr1);
console.log();
console.log(arr2);


