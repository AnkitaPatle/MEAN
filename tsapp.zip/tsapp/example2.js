var arr1;
arr1 = new Array();
var arr2 = [];
arr1.push("ankita");
arr1.push("Shobha");
arr1.push("mahesh");
arr1.push("Rahul");
arr1.push("ram");
arr1.push("neha");
for (var i = 0; i < arr1.length; i++) {
    for (var j = 0; j < arr1.length; j++) {
        var char1 = arr1[i].charAt(0);
        var char2 = arr1[j].charAt(0);
        if (char1.toUpperCase() === char2) {
            arr2.push(arr1[i]);
        }
    }
}
console.log(arr1);
console.log();
console.log(arr2);
