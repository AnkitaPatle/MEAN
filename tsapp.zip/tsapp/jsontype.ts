//The JSON object aka object literal
let product = {
    ProductID: 101,
    ProductName: "Laptop",
};
// 1. JSON serialization aka string parsing for JSON
console.log(JSON.stringify(product));
// 2. gettng length of all keys of JSON object
let info = Object.keys(product).length;
console.log(info);
console.log();
// 3. Read all property names
for(let p of Object.keys(product)){
    console.log(p);
}

let namesData = [];
namesData.push({id: 102, name:"A"});
namesData.push({id: 102, name:"B"});
namesData.push({id: 102, name:"C"});
namesData.push({id: 102, name:"D"});