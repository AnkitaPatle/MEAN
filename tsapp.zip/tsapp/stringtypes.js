//variable names must start from lower case
//use camel-case for multiword variable name
var firstName = "Ankita";
var middleName = "Shobha";
var lastName = "Hema";
// 1. concatinate using old JS style(ES 3 to 5)
var fullNameOld = firstName + " " + middleName + " " + lastName;
console.log("Full name with old style " + fullNameOld);
var fullNameWithTempletString = firstName + " " + middleName + " " + lastName;
console.log("with Templet String     \n                                " + fullNameWithTempletString);
