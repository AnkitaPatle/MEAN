// 1. explicit data-type
let num1: number = 200;
// 2. implicit data-type, based on type-of initial value
let num2: number = 200;

function performOperation(val:any){
    if(typeof(val)==="number"){
        console.log("Square" +(val*val));
    }else{

    if(typeof(val)==="string"){
        console.log("Upper Case "+val.toUpperCase());
    }else{
        console.log("Sorry!! Type not found to process "+val);
        }
    }
}
performOperation(10);
performOperation("Ankita");
performOperation(true);

function unionTypeOperation(val: number | string){
    if(typeof(val)==="number"){
        console.log("Square" +(val*val));
    }

    if(typeof(val)==="string"){
        console.log("Upper Case "+val.toUpperCase());
    }
}
unionTypeOperation(10);
unionTypeOperation("Ram");